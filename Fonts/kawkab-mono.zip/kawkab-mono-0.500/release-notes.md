# Kawkab Mono كوكب مونو
## Release Notes

### v0.500 - 2015-12-17
- Font is now paired with [Source Code Pro](https://github.com/adobe-fonts/source-code-pro) instead of PT Mono. Source Code Pro makes available its Masters files so this allows us to precisely choose and interpolate the most suitable weight for pairing non-Arabic glyphs with Arabic ones.
- Created a Light design master.
- Font is available in 3 weights: Light, Regular and Bold.
- Previous Regular weight is now reclassified as Bold.
- Improved س and ص glyphs.
- Various outline improvements to several other glyphs.
- Added release-notes.md (this file).

### v0.101 - 2015-11-10
- Initial public release.
- Improved metadata and license information for PT Mono.